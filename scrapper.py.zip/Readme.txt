Install python3 on your computer and then type : 

pip install -r requirements.txt

and then 
 python3 scrapper.py
